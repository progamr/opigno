function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6bFH2WQ11lP":
        Script1();
        break;
  }
}

function Script1()
{
  window.print()
}

